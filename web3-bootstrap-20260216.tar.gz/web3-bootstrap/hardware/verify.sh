#!/usr/bin/env bash
set -euo pipefail

MEM_GB=$(free -g | awk '/^Mem:/{print $2}')
DISK_GB=$(df -BG / | awk 'NR==2{gsub("G", "", $4); print $4}')

echo "Memory GB: $MEM_GB"
echo "Free disk GB: $DISK_GB"

test "$MEM_GB" -ge 1 || { echo "FAIL: need >=1GB RAM"; exit 1; }
test "$DISK_GB" -ge 10 || { echo "FAIL: need >=10GB free disk"; exit 1; }

echo "PASS"
